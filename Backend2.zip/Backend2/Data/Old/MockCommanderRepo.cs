// using Commander.Models;

// namespace Commander.Data
// {
//     public class MockCommanderRepo : ICommanderRepo
//     {
//         public void Create()
//         {
//             throw new NotImplementedException();
//         }

//         public void Create(Command c1)
//         {
//             throw new NotImplementedException();
//         }

//         public IEnumerable<Command> GetAppCommands()
//         {
//             var Data=new List<Command>(){
//             new Command{Id=1 , HowTo=" By clicking " ,Line=" Download Video " , PlatForm="Google Chorme"},
//             new Command {Id=1 , HowTo=" By Pointing " ,Line=" Move Cursor " , PlatForm="Mouse"},
//             new Command {Id=1 , HowTo=" Doing Wudu " ,Line=" Praying Namaz " , PlatForm="Masjid"}
//             };
//             return Data;
//         }

//         public Command GetCommandById(int id)
//         {
//             return new Command{Id=1 , HowTo=" By clicking " ,Line=" Download Video " , PlatForm="Google Chorme"};
//         }
//     }
// }
//  Now Mocve on Controller