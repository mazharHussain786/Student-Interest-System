import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { MyApiService } from '../../my-api.service';
import { Observer, tap } from 'rxjs';
import { Router, RouterLink } from '@angular/router';
import { NavbarComponent } from '../../Navbar/navbar/navbar.component';
import { JwtHelperService } from '@auth0/angular-jwt';

@Component({
  selector: 'app-add-student',
  standalone: true,
  imports: [CommonModule , FormsModule,HttpClientModule,RouterLink,NavbarComponent],
  templateUrl: './add-student.component.html',
})
export class AddStudentComponent {
  City:string[]=["Lahore","Mailsi" ,"Multan" , "BahwalPur" ,"Qasoor","Islamabad"]
  Gender:string[]=["Male" ,"Female" ,"Not say"]
  Degrees:string[]=["Associate Degree", "Bachelor Degree" ,"PostGraduate Degree" ,"Mphill degree","Doctrate" ,"Post-Doctarate"]


  Interest:string[]=[]

  Form:any={}; 

  btn:Boolean;

  
  status:string=""

  apiUrl:string = 'http://localhost:5264/api/commands';

token:any
 
LoadedFailed:Boolean=false;
  constructor(private http: HttpClient,private router:Router) 
  {
    this.token=localStorage.getItem('token');
    if(!this.token)
    {
      this.LoadedFailed=true;
    }
    else
    {
      const helper = new JwtHelperService();
      const decodedToken = helper.decodeToken(this.token);

      const userRole = decodedToken['Role'];
      if(userRole=="Student")
      {
        this.LoadedFailed=true;
      }
   
    }
    this.btn=false;
  }
  ngOnInit():void
  {
    this.getAllInterests();
    this.status=""
  }



  onSubmit(): void {
    // Set the headers to specify JSON content type and include the token
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `${this.token}`,
    });

    this.http.post(this.apiUrl, this.Form, { headers, responseType: 'text' }).subscribe({
      next: (response) => {
        console.log('API Response:', response);
        this.status = response;
      },
      error: (error) => {
        console.log('API Error:', error);
      },
      complete: () => {
        console.log('API Request completed');
        this.router.navigate(['/stdlist']);
      },
    });
  }

  getAllInterests(): void {
    // Set the headers to include the token
    const headers = new HttpHeaders({
      'Authorization': `${this.token}`,
    });

    this.http.get<any[]>(`${this.apiUrl}/interest`, { headers }).pipe(
      tap((data: string[]) => {
        console.log('Received Interests:', data);
        this.Interest = data;
      })
    ).subscribe();
  }
}
