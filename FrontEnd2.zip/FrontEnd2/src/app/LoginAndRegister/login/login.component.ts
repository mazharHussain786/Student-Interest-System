import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { finalize, tap } from 'rxjs';
import { JwtHelperService } from '@auth0/angular-jwt';


@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, RouterLink, CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  LoginData: any = {};
  LoginFailed: boolean = false;
  token: any;

  constructor(private httpClient: HttpClient, private router: Router)
   {
    localStorage.removeItem('token');
   }

  login() {
    this.httpClient
      .post('http://localhost:5264/api/Commands/Login', this.LoginData)
      .pipe(
        tap((response: any) => {
          console.log('Server response', response);

          this.token = response.token;
          console.log(this.token);
          if(!this.token)
          {
            this.LoginFailed=true;
            return;
          }
          const helper = new JwtHelperService();
          const decodedToken = helper.decodeToken(this.token);

          // Access claims
          const userEmail = decodedToken['Email'];
          const userRole = decodedToken['Role'];
          const userFullName = decodedToken['FullName'];




          console.log(userEmail,userRole,userFullName);

          if(userRole=="Student")
          {
            localStorage.removeItem('token');
            localStorage.setItem('token',this.token);
            this.router.navigate(['/dashboard'])
          }
          else
          {
            localStorage.removeItem('token');
            localStorage.setItem('token',this.token);
            this.router.navigate(['/AddStd'])
          }
        
        }),
        finalize(() => {
          console.log('Request completed successfully.');
        })
      )
      .subscribe(
        () => {},
        (error) => {
          console.log('Error:', error);
          this.LoginFailed = true;
        }
      );
  }
}
