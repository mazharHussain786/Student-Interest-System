using System.ComponentModel.DataAnnotations;

namespace Commander.Models
{
    public class Interest
    {
        public int Id {get ;set;}
        [Required (ErrorMessage ="Interest cannot be empty")]
        public string? Inter{get ;set ;}
        
    }
}