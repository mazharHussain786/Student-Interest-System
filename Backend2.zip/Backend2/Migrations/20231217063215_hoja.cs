﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Commander.Migrations
{
    /// <inheritdoc />
    public partial class hoja : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Commands_Interests_InterId",
                table: "Commands");

            migrationBuilder.RenameColumn(
                name: "InterId",
                table: "Commands",
                newName: "InterestId");

            migrationBuilder.RenameIndex(
                name: "IX_Commands_InterId",
                table: "Commands",
                newName: "IX_Commands_InterestId");

            migrationBuilder.AddForeignKey(
                name: "FK_Commands_Interests_InterestId",
                table: "Commands",
                column: "InterestId",
                principalTable: "Interests",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Commands_Interests_InterestId",
                table: "Commands");

            migrationBuilder.RenameColumn(
                name: "InterestId",
                table: "Commands",
                newName: "InterId");

            migrationBuilder.RenameIndex(
                name: "IX_Commands_InterestId",
                table: "Commands",
                newName: "IX_Commands_InterId");

            migrationBuilder.AddForeignKey(
                name: "FK_Commands_Interests_InterId",
                table: "Commands",
                column: "InterId",
                principalTable: "Interests",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
