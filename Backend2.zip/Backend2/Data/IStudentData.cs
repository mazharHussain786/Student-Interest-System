using Commander.Models;

namespace Commander.Data
{
    public interface IStudentEndPoints
    {
        bool SaveStudent(Command c1);

        bool DeleteStudent(int id);

        Command UpdateStudent(Command c1);
 
        object GetAllStudent( int v);

        List<string> GetAllDegrees();

        List<string> GetAllInterst();

        List<string> GetAllDepartments();

        List<string> GetTop5Intersets();
        List<string> GetBottom5Interests();

        Command? GetStudent(int id);
        public Dictionary<string,int> Info();
        Register Register(RegisterDto r1);
        public string Login(Login login);
}
}