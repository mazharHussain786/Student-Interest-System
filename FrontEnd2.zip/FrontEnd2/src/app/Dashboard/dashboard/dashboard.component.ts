import { CommonModule } from '@angular/common';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { tap } from 'rxjs';
import { NavbarComponent } from '../../Navbar/navbar/navbar.component';

@Component({
  selector: 'app-dashboard',
  standalone:true,
  templateUrl: './dashboard.component.html',
  imports:[CommonModule,NavbarComponent],
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  apiUrl: string = 'http://localhost:5264/api/commands';
  Top5: string[] = [];
  Bottom5: string[] = [];
  Infoo: { [key: string]: number } = {};
  TotalCount: any;
  LoadedFail:Boolean=false
  token: any;

  constructor(private http: HttpClient) {
   
   
  }

  ngOnInit() {
    // Check if the token is empty before making HTTP requests
    this.token = localStorage.getItem('token');
    if(!this.token)
    {
      this.LoadedFail=true;
    }
    console.log(this.token);
    if (this.token) {
      this.getTop5();
      this.getBottom5();
      this.getInfo();
    } else {
      console.log('Token is empty. Not making requests.');
    }
  }

  getTop5(): void {
    const headers = this.createHeaders();

    this.http.get<any[]>(`${this.apiUrl}/interest/Top5`, { headers }).pipe(
      tap((data: string[]) => {
        console.log('Received Top5 Interests:', data);
        this.Top5 = data;
      })
    ).subscribe();
  }

  getBottom5(): void {
    const headers = this.createHeaders();

    this.http.get<any[]>(`${this.apiUrl}/interest/Bottom5`, { headers }).pipe(
      tap((data: string[]) => {
        console.log('Received Bottom5 Interests:', data);
        this.Bottom5 = data;
        this.TotalCount = this.Bottom5.pop();
      })
    ).subscribe();
  }

  getInfo(): void {
    const headers = this.createHeaders();

    this.http.get<any>(`${this.apiUrl}/Dashboard/info`, { headers }).pipe(
      tap((data: { [key: string]: number }) => {
        console.log('Received Info:', data);
        this.Infoo = data;
      })
    ).subscribe();
  }

  private createHeaders(): HttpHeaders {
    return new HttpHeaders({
      'Authorization': `${this.token}`
    });
  }
}
