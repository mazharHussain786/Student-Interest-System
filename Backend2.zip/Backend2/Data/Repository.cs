using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Commander.Models;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc.ViewComponents;
using Microsoft.IdentityModel.Tokens;

namespace Commander.Data
{
    public class StudentClass : IStudentEndPoints
    {
        private CommanderContext Context { get; set; }

        public StudentClass(CommanderContext c1)
        {
            Context = c1;
        }

        public List<string> GetAllDegrees()
        {
            var AllDegrees = Context.Commands.Select(c => c.DegreeTitle).Distinct().ToList();
            return AllDegrees;
        }

        public List<string> GetAllDepartments()
        {
            var AllDepartments = Context.Commands.Select(c => c.Department).Distinct().ToList();
            return AllDepartments;
        }

        public List<string> GetAllInterst()
        {
            var InterestList = Context.Commands.Select(c => c.Inter).Distinct().ToList();
            return InterestList;
        }

        public object GetAllStudent(int pageNo)
        {
            int pageSize = 10;
            var Students = Context.Commands.ToList();
            var Total = Students.Count;

            var skipedValue = (pageNo - 1) * pageSize;
            Total -= skipedValue;
            Console.WriteLine("Page No" + pageNo);
            Console.WriteLine("SkippedVALUE" + skipedValue);

            if (Total < pageSize)
            {
                pageSize = Total;
            }
            var pageData = Students.Skip(skipedValue).Take(pageSize).ToList();
            Console.WriteLine("Page Count " + pageData.Count);
            var result = new
            {
                Data = pageData,
                totalPages = (int)Math.Ceiling((double)Total / pageSize)
            };
            return result;
        }
        public Command? GetStudent(int id)
        {
            var student = Context.Commands.FirstOrDefault(c => c.Id == id);
            return student;
        }

        public List<string> GetTop5Intersets()
        {
            var AllInterests = Context.Commands.Select(c => c.Inter).ToList();
            Console.WriteLine(AllInterests.Count);
            int n = Context.Commands.Select(c => c.Inter).Distinct().ToList().Count;
            if (n > 5)
            {
                n = 5;
            }
            // Now we have the column of ineterst table we have to pick from these
            var Top5Object = AllInterests.GroupBy(i => i).OrderByDescending(g => g.Count()).Take(n).Select(g => g.Key).ToList();
            if (!Top5Object.Any())
            {
                return new List<string>();
            }
            // Now we have picked the interests..


            return Top5Object;
        }
        public List<string> GetBottom5Interests()
        {
            var allInterests = Context.Commands.Select(c => c.Inter).ToList();

            int count = Context.Commands.Select(c => c.Inter).Distinct().ToList().Count;

            // Now we have the column of interest table we have to pick from these
            var bottom5Interests = allInterests
                .GroupBy(i => i)
                .OrderBy(g => g.Count())
                .Take(count)
                .Select(g => g.Key)
                .ToList();
            bottom5Interests.Add(count.ToString());
            Console.WriteLine(bottom5Interests);
            return bottom5Interests;
        }

        public bool SaveStudent(Command c1)
        {
            var SavedInstance = Context.Commands.FirstOrDefault(c => c.RollNo == c1.RollNo);
            if (SavedInstance == null)
            {
                Console.WriteLine(c1.Inter); // Print the Inter value for debugging






                // Now, add the command
                Context.Commands.Add(c1);
                Context.SaveChanges();
                return true;
            }

            return false;
        }



        public bool DeleteStudent(int id)
        {
            var RemoveStudent = Context.Commands.FirstOrDefault(c => c.Id == id);
            if (RemoveStudent != null)
            {
                _ = Context.Commands.Remove(RemoveStudent);
                Context.SaveChanges();
                return true;
            }
            else
            {
                return false;
            }
        }



        public Command UpdateStudent(Command c1)
        {
            var st = Context.Commands.FirstOrDefault(c => c.Id == c1.Id);
            st.City = c1.City;
            st.DegreeTitle = c1.DegreeTitle;
            st.DOB = c1.DOB;
            st.Email = c1.Email;
            st.StartDate = c1.StartDate;
            st.EndDate = c1.EndDate;
            st.Subject = c1.Subject;
            st.FullName = c1.FullName;
            st.Department = c1.Department;
            st.Inter = c1.Inter;
            st.Gender = c1.Gender;
            Context.SaveChanges();
            return st;
        }

        public Dictionary<string, int> Info()
        {
            var allStudents = Context.Commands.ToList();
            if (!allStudents.Any())
            {
                return new Dictionary<string, int>();
            }

            // Get the current date
            DateTime currentDate = DateTime.Now;

            // Number of students currently studying in university
            int currentlyStudyingCount = allStudents.Count(s => s.StartDate <= currentDate && (s.EndDate == null || s.EndDate >= currentDate));

            // Number of students recently enrolled (within the last 30 days for example)
            int recentlyEnrolledCount = allStudents.Count(s => s.StartDate >= currentDate.AddDays(-30));

            // Number of students about to graduate (within the next 30 days for example)
            int aboutToGraduateCount = allStudents.Count(s => s.EndDate != null && s.EndDate <= currentDate.AddDays(30));

            // Number of students graduated
            int graduatedCount = allStudents.Count(s => s.EndDate != null && s.EndDate <= currentDate);

            var infoDictionary = new Dictionary<string, int>
            {
                { "Currently Studying", currentlyStudyingCount },
                { "Recently Enrolled", recentlyEnrolledCount },
                { "About to Graduate", aboutToGraduateCount },
                { "Graduated", graduatedCount }
            };

            return infoDictionary;
        }
        public Register Register(RegisterDto request)
        {
            // Check if the user with the given email already exists
            var existingUser = Context.Registers.FirstOrDefault(c => c.Email == request.Email);
            if (existingUser != null)
            {
                return null; // User with the email already exists
            }

            // Create a new user


            // Create unique password salt for each user
            CreatePasswordHash(request.Password, out byte[] passwordHash, out byte[] passwordSalt);
            Register user = new Register();
            user.Email = request.Email;
            user.FullName = request.FullName;
            user.Role = "Student";
            // Set the password hash and salt for the user
            user.PasswordHash = passwordHash;
            user.PasswordSalt = passwordSalt;
            // Add the user to the database
            Context.Registers.Add(user);
            Context.SaveChanges(); // Save changes to the database

            return user; // Registration successful
        }

        private void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(password + Convert.ToBase64String(passwordSalt)));
            }
        }

        public string Login(Login login)
        {
            var user = Context.Registers.FirstOrDefault(c => c.Email == login.Email);
            if (user == null)
            {
                Console.WriteLine("gya");
                return "";
            }

            if (user != null && VerifyPassword(login.Password, user.PasswordHash, user.PasswordSalt))
            {
                // User authenticated successfully

                // Create claims for the token
                var claims = new[]
                {
            new Claim("Email", user.Email),
            new Claim("Role", user.Role), // Replace with the actual user role
            new Claim("FullName", user.FullName),
            // Add other claims as needed
        };

                // Generate a secure random key
                var key = GenerateRandomKey();
                var creds = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);

                var token = new JwtSecurityToken(
                    claims: claims,
                    expires: DateTime.Now.AddHours(1), // Set the token expiration time
                    signingCredentials: creds
                );

                var tokenString = new JwtSecurityTokenHandler().WriteToken(token);
                Console.WriteLine(tokenString);
                return tokenString;
            }

            return null;
        }

        private byte[] GenerateRandomKey()
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                var key = new byte[32]; // 256 bits
                rng.GetBytes(key);
                return key;
            }
        }

        private bool VerifyPassword(string password, byte[] storedHash, byte[] storedSalt)
        {
            using (var hmac = new HMACSHA512(storedSalt))
            {
                var computedHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(password + Convert.ToBase64String(storedSalt)));
                Console.WriteLine(computedHash);
                return computedHash.SequenceEqual(storedHash);
            }
        }
    }
}



//  total info
