using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Commander.Models
{
    public class Command
    {
        [Key]
        public int Id {get ; set;}
        [Required(ErrorMessage = "FullName is required.")]
        public string FullName { get; set; }=String.Empty;

      
       [Required (ErrorMessage ="RollNo is required")]
        public string RollNo { get; set; }=String.Empty;

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Invalid email format.")]
   
        public string Email { get; set; }=String.Empty;

       

        public string Gender {get ; set;}=String.Empty;

        [Required(ErrorMessage = "DOB is required.")]
        public DateTime DOB { get; set; }

        [Required(ErrorMessage = "City is required.")]
        public string City { get; set; }=String.Empty;

        [Required(ErrorMessage = "Department is required.")]
        public string Department { get; set; }=String.Empty;

        [Required(ErrorMessage = "DegreeTitle is required.")]
        public string DegreeTitle { get; set; }=String.Empty;

        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        [Required (ErrorMessage ="Intrest cannot empty")]
        public required string Inter { get; set; }

        public string? Subject {get ; set;}
    }
}