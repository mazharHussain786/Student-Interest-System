// using Commander.Models;
// namespace Commander.Data
// {
//     // here we will define the functions..only define
//     public interface ICommanderRepo
//     {
//         IEnumerable<Command> GetAppCommands();
//         Command GetCommandById(int id);
//         void Create(Command c1);

//     }
// }