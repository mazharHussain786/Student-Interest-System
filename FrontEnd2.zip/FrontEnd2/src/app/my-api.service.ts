import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class MyApiService {
  private apiUrl = 'http://localhost:5264/api/commands'; // Update with your API endpoint

  constructor(private http: HttpClient) {}

  saveStudent(data: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, data);
  }
}
