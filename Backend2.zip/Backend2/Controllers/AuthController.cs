using System.Runtime.CompilerServices;
using Commander.Data;
using Commander.Models;
using Newtonsoft.Json;

using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.Text.Json;


namespace Commander.Controller
{
    // here we make class of Controller inherited with Conytroller
    [Route("api/commands/auth")]
    [ApiController]
    
    public class AuthController : ControllerBase
    {
   

    

    }
}