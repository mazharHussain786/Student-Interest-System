// using Commander.Models;

// namespace Commander.Data
// {
//     public class DataBaseMock : ICommanderRepo
//     {
//         private readonly CommanderContext _contenxt;

//         public DataBaseMock(CommanderContext context)
//         {
//             _contenxt=context;
//         }

//         public void Create(Command c1)
//         {
//             _contenxt.Commands.Add(c1);
//             _contenxt.SaveChanges();
//         }


//         public IEnumerable<Command> GetAppCommands()
//         {
//             return _contenxt.Commands.ToList();
//         }

//         public Command? GetCommandById(int id)
//         {

//             return _contenxt.Commands.FirstOrDefault(c => c.Id == id);
//         }
//     }
// }