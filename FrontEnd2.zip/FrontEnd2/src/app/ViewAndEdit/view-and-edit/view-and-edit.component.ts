import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Component, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { tap } from 'rxjs';
import { NavbarComponent } from '../../Navbar/navbar/navbar.component';
import { JwtHelperService } from '@auth0/angular-jwt';



@Component({
  selector: 'app-view-and-edit',
  standalone: true,
  imports: [HttpClientModule,CommonModule,NavbarComponent],
  templateUrl: './view-and-edit.component.html',
  styleUrl: './view-and-edit.component.css'
})
export class ViewAndEditComponent {

  Student:any
  id:any
  apiUrl:string = 'http://localhost:5264/api/commands/view';
  token:any
  Status:Boolean=false;
  EditProperty:String="true";
  LoadedFailed:Boolean=false

  constructor(private http:HttpClient,private route: ActivatedRoute, private router: Router)
  {
    this.token=localStorage.getItem('token');
    if(!this.token)
    {
      this.LoadedFailed=true;
    }
    else
    {
      const helper = new JwtHelperService();
      const decodedToken = helper.decodeToken(this.token);
      const userRole = decodedToken['Role'];

      if(userRole=="Student")
      {
        this.LoadedFailed=true;
      }
    }
  }
  ngOnInit(): void {
    // Access the id parameter from the route
    this.route.params.subscribe(params => {
      this.id = params['id'];
      console.log('Student ID:', this.id);
      this.getOneStudent();
      // Now you can use the studentId as needed in your component
    });
  }


    getOneStudent(): void {

      const headers = new HttpHeaders({
        'Authorization': `${this.token}`,
      });

    this.http.get<any>(`${this.apiUrl}/${this.id}`,{headers}).pipe(

      tap((data: any) => {
        console.log('Received Data:', data);
        this.Student=data;
      })
    ).subscribe();

   
  }

 
  



}
