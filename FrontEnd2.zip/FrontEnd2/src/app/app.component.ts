import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AddStudentComponent } from './AddStudent/add-student/add-student.component';
import { HttpClientModule } from '@angular/common/http';
import { MyApiService } from './my-api.service';
import { BrowserModule } from '@angular/platform-browser';
import { ShowDataComponent } from './ShowData/show-data/show-data.component';
import { DashboardComponent } from './Dashboard/dashboard/dashboard.component';
import { LoginComponent } from './LoginAndRegister/login/login.component';
import { RegisterComponent } from './LoginAndRegister/register/register.component';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone:true,
  styleUrls: ['./app.component.css'],
  imports: [CommonModule, RouterModule, AddStudentComponent, HttpClientModule,ShowDataComponent,ShowDataComponent,DashboardComponent,LoginComponent,RegisterComponent],
})
export class AppComponent {
  title = 'FrontEnd';


 
}
