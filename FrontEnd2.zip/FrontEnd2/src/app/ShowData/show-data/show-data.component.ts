import { Component, EventEmitter, Output } from '@angular/core';
import {  HttpClientModule,HttpClient, HttpHeaders } from '@angular/common/http';
import { map, tap } from 'rxjs';
import { CommonModule } from '@angular/common';
import { ChangeDetectorRef } from '@angular/core';
import { ViewAndEditComponent } from '../../ViewAndEdit/view-and-edit/view-and-edit.component';
import { RouterLink, RouterModule } from '@angular/router'; 
import { routes } from '../../app.routes';
import { NavbarComponent } from '../../Navbar/navbar/navbar.component';
import { JwtHelperService } from '@auth0/angular-jwt';


@Component({
  selector: 'app-show-data',
  standalone: true,
  imports: [HttpClientModule,CommonModule,ViewAndEditComponent,RouterLink,NavbarComponent],
  templateUrl: './show-data.component.html',
  styleUrl: './show-data.component.css'
})





export class ShowDataComponent {

  apiUrl:string = 'http://localhost:5264/api/commands';
  StudentData:any[]=[]

  totalPages?:number
  form:{}={}

  showViewAndEdit = false;

  pageNo:number=1
  
  pageSize:number=10

  editProperty:String="false"


  @Output() ShowStudent:EventEmitter<any>=new EventEmitter();


  btnName:String="Edit"

  token:any
 
  LoadedFailed:Boolean=false;



  constructor(private http: HttpClient) 
  {
    this.token=localStorage.getItem('token');
    if(!this.token)
    {
      this.LoadedFailed=true;
    }
    else
    {
      const helper = new JwtHelperService();
      const decodedToken = helper.decodeToken(this.token);
      const userRole = decodedToken['Role'];

      if(userRole=="Student")
      {
        this.LoadedFailed=true;
      }
    }
  }
  ngOnInit()
  {
    this.getAllStudents();
  }

  getAllStudents(): void {
    
  const headers = new HttpHeaders({
    'Authorization': `${this.token}`,
  });
    this.http.get<ApiResponse>(`${this.apiUrl}?pageNo=${this.pageNo}`,{headers}).pipe(

      tap((data: ApiResponse) => {
        console.log('Received Interests:', data.data);
        this.StudentData=data.data
        this.totalPages=data.totalPages
      })
    ).subscribe();
  }
  // we will call it to corresponding btn
  ChangePageNumber(page:number)
  {
    this.pageNo=page;
    console.log(this.pageNo)
    this.getAllStudents();
  }
  RemoveStudent(id:String)
  {
    const headers = new HttpHeaders({
      'Authorization': `${this.token}`,
    });
    this.http.delete<any>(`${this.apiUrl}?id=${id}`,{headers}).subscribe((response)=>
    {
      console.log("Student Deleted Successfully",response);
    },
    (error)=>
    {
      console.log(error);
    }
    )
    for(let i=0 ; i<this.StudentData.length ; i++)
    {
      if(this.StudentData[i].id==id)
      {
        this.StudentData.splice(this.StudentData[i],1);
      }
    }

  }


  

}
interface ApiResponse {
  data: Array<any>;
  totalPages: number;
}
