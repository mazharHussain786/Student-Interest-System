import { Routes } from '@angular/router';
import { AddStudentComponent } from './AddStudent/add-student/add-student.component';
import { ShowDataComponent } from './ShowData/show-data/show-data.component';
import { ViewAndEditComponent } from './ViewAndEdit/view-and-edit/view-and-edit.component';
import { EditDataComponent } from './ViewAndEdit/edit-data/edit-data.component';
import { RegisterComponent } from './LoginAndRegister/register/register.component';
import { LoginComponent } from './LoginAndRegister/login/login.component';
import { DashboardComponent } from './Dashboard/dashboard/dashboard.component';

export const routes: Routes = [
    {path:'',component:LoginComponent},
    {path:'AddStd',component:AddStudentComponent},
    {path:'stdlist',component:ShowDataComponent},
    {path:'view/:id',component:ViewAndEditComponent},
    {path:'Edit/:id',component:EditDataComponent},
    {path:'AddStudent',component:AddStudentComponent},
    {path:'Register',component:RegisterComponent},
    {path:'Login',component:LoginComponent},
    {path:'dashboard',component:DashboardComponent}
];