import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule,RouterLink,CommonModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  constructor(private httpClient:HttpClient, private router:Router)
  {

  }
  RegisterFailed:Boolean=false;
  RegisterData:any={}
  Register()
  {
    this.httpClient.post('http://localhost:5264/api/Commands/Register',this.RegisterData).subscribe((response:any)=>
    {
      if(response)
      {
        this.router.navigate(['/Login'])
      }
      console.log(response);
    },
    (error)=>
    {
      console.log(error);
    }
    )
    console.log(this.RegisterData);
  }
}
