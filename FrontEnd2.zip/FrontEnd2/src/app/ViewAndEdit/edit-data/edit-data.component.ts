import { CommonModule } from '@angular/common';
import {
  HttpClient,
  HttpClientModule,
  HttpHeaders,
} from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Observer, tap } from 'rxjs';
import { DatePipe } from '@angular/common';
import { NavbarComponent } from '../../Navbar/navbar/navbar.component';
import { JwtHelperService } from '@auth0/angular-jwt';

@Component({
  selector: 'app-edit-data',
  standalone: true,
  imports: [HttpClientModule, CommonModule, FormsModule, RouterLink,NavbarComponent],
  templateUrl: './edit-data.component.html',
  styleUrl: './edit-data.component.css',
})
export class EditDataComponent {
  apiUrl: string = 'http://localhost:5264/api/commands';

  id: any;
  Form: any;
  LoadedFailed:Boolean=false

  City: string[] = [
    'Lahore',
    'Mailsi',
    'Multan',
    'BahwalPur',
    'Qasoor',
    'Islamabad',
  ];
  Gender: string[] = ['Male', 'Female', 'Not say'];
  Degrees: string[] = [
    'Associate Degree',
    'Bachelor Degree',
    'PostGraduate Degree',
    'Mphill degree',
    'Doctrate',
    'Post-Doctarate',
  ];

  Interest: string[] = [];
  token: any;

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.token=localStorage.getItem('token');
    if(!this.token)
    {
      this.LoadedFailed=true;
    }
    else
    {
      const helper = new JwtHelperService();
      const decodedToken = helper.decodeToken(this.token);
      const userRole = decodedToken['Role'];

      if(userRole=="Student")
      {
        this.LoadedFailed=true;
      }
    }
  }

  // now we have to get the id from previous componenet

  ngOnInit(): void {
    // Access the id parameter from the route
    this.route.params.subscribe((params) => {
      this.id = params['id'];
      console.log('Student ID:', this.id);
      this.getOneStudent();
      this.getAllInterests();

      // Now you can use the studentId as needed in your component
    });
  }

  getOneStudent(): void {
    const headers = new HttpHeaders({
      Authorization: `${this.token}`,
    });

    this.http
      .get<any>(`${this.apiUrl}/View/${this.id}`, { headers })
      .pipe(
        tap((data: any) => {
          console.log('Received Data:', data);
          this.Form = data;
        })
      )
      .subscribe();
  }
  getAllInterests(): void {
    const headers = new HttpHeaders({
      Authorization: `${this.token}`,
    });

    this.http
      .get<any[]>(`${this.apiUrl}/interest`, { headers })
      .pipe(
        tap((data: string[]) => {
          console.log('Received Interests:', data);
          this.Interest = data;
        })
      )
      .subscribe();
  }
  Submit() {
    const myObserver: Observer<any> = {
      next: (response) => {
        console.log('API Response:', response);
        // Handle the response as needed
      },
      error: (error) => {
        console.log('API Error:', error);
        // Handle errors as needed
      },
      complete: () => {
        console.log('API Request completed');
        // Additional logic after request completion, if needed
      },
    };

    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `${this.token}`,
    });
    this.http
      .patch(`${this.apiUrl}/${this.id}`, JSON.stringify(this.Form), {
        headers,
        responseType: 'text',
      })
      .subscribe(myObserver);
  }
}
