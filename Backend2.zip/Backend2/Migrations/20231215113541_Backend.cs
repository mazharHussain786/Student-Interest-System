﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Commander.Migrations
{
    /// <inheritdoc />
    public partial class Backend : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "HowTo",
                table: "Commands");

            migrationBuilder.DropColumn(
                name: "Line",
                table: "Commands");

            migrationBuilder.DropColumn(
                name: "PlatForm",
                table: "Commands");

            migrationBuilder.AddColumn<string>(
                name: "City",
                table: "Commands",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "DOB",
                table: "Commands",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "DegreeTitle",
                table: "Commands",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Department",
                table: "Commands",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Email",
                table: "Commands",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "EndDate",
                table: "Commands",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "FullName",
                table: "Commands",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<int>(
                name: "InterId",
                table: "Commands",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "RollNo",
                table: "Commands",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "StartDate",
                table: "Commands",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.CreateTable(
                name: "Interests",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Inter = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Interests", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Commands_InterId",
                table: "Commands",
                column: "InterId");

            migrationBuilder.AddForeignKey(
                name: "FK_Commands_Interests_InterId",
                table: "Commands",
                column: "InterId",
                principalTable: "Interests",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Commands_Interests_InterId",
                table: "Commands");

            migrationBuilder.DropTable(
                name: "Interests");

            migrationBuilder.DropIndex(
                name: "IX_Commands_InterId",
                table: "Commands");

            migrationBuilder.DropColumn(
                name: "City",
                table: "Commands");

            migrationBuilder.DropColumn(
                name: "DOB",
                table: "Commands");

            migrationBuilder.DropColumn(
                name: "DegreeTitle",
                table: "Commands");

            migrationBuilder.DropColumn(
                name: "Department",
                table: "Commands");

            migrationBuilder.DropColumn(
                name: "Email",
                table: "Commands");

            migrationBuilder.DropColumn(
                name: "EndDate",
                table: "Commands");

            migrationBuilder.DropColumn(
                name: "FullName",
                table: "Commands");

            migrationBuilder.DropColumn(
                name: "InterId",
                table: "Commands");

            migrationBuilder.DropColumn(
                name: "RollNo",
                table: "Commands");

            migrationBuilder.DropColumn(
                name: "StartDate",
                table: "Commands");

            migrationBuilder.AddColumn<string>(
                name: "HowTo",
                table: "Commands",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Line",
                table: "Commands",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PlatForm",
                table: "Commands",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
