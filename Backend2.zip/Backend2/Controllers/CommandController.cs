using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Commander.Data;
using Commander.Models;
using System.Security.Claims;

namespace Commander.Controller
{
    [Route("api/commands")]
    [ApiController]
    public class CommandController : ControllerBase
    {
        private readonly IStudentEndPoints _repository;

        public CommandController(IStudentEndPoints repository)
        {
            _repository = repository;
        }

        private string ValidateTokenAndGetRole()
        {
            var authorizationHeader = HttpContext.Request.Headers["Authorization"];
            Console.WriteLine(authorizationHeader);
            var token = authorizationHeader.ToString().Replace("Bearer ", "");

            try
            {
                // Validate the token manually
                var handler = new JwtSecurityTokenHandler();
                var jsonToken = handler.ReadToken(token) as JwtSecurityToken;

                if (jsonToken == null)
                {
                    // Token validation failed
                    return string.Empty;
                }

                // Access claims from the token
                var roleClaim = jsonToken.Claims.FirstOrDefault(c => c.Type =="Role")?.Value;
                Console.WriteLine(roleClaim);
                return roleClaim;
            }
            catch (Exception)
            {
                // Handle exceptions
                return string.Empty;
            }
        }


        [HttpGet]
        public ActionResult<List<Command>> GetAllStudent(int pageNo = 1)
        {
            var roleClaim = ValidateTokenAndGetRole();

            if (string.IsNullOrEmpty(roleClaim) || roleClaim != "Admin")
            {
                return Forbid();
            }

            var data = _repository.GetAllStudent(pageNo);
            if (data == null)
            {
                return NoContent();
            }
            return Ok(data);
        }


        [HttpPost]
        public ActionResult SaveStudent([FromBody] Command c1)
        {
            var roleClaim = ValidateTokenAndGetRole();

            if (string.IsNullOrEmpty(roleClaim) || roleClaim != "Admin")
            {
                return Forbid();
            }

            try
            {
                if (_repository.SaveStudent(c1))
                {
                    return Ok("Student is Saved Successfully");
                }
                else
                {
                    return Ok("Failed to Save Student");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                return StatusCode(500, "Internal Server Error");
            }
        }


        [Route("interest")]
        [HttpGet]
        public ActionResult<List<string>> GetInterests()
        {
            var roleClaim = ValidateTokenAndGetRole();

            if (string.IsNullOrEmpty(roleClaim) || roleClaim != "Admin")
            {
                return Forbid();
            }

            var data = _repository.GetAllInterst();
            return Ok(data);
        }


        [Route("interest/Top5")]
        [HttpGet]
        public ActionResult<List<string>> GetTop5Interests()
        {
            var roleClaim = ValidateTokenAndGetRole();

            if (string.IsNullOrEmpty(roleClaim) || (roleClaim != "Student" && roleClaim!="Admin"))
            {
                return Forbid();
            }

            try
            {
                var data = _repository.GetTop5Intersets();
                return Ok(data);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
                return StatusCode(500, "Internal Server Error");
            }
        }

        [Route("interest/Bottom5")]
        [HttpGet]
        public ActionResult<List<string>> GetBottom5Interests()
        {
            var roleClaim=ValidateTokenAndGetRole();
            if (string.IsNullOrEmpty(roleClaim) || (roleClaim != "Student" && roleClaim!="Admin") )
            {
                return Forbid();
            }
            var data = _repository.GetBottom5Interests();
            return Ok(data);
        }

        [Route("/departments")]
        [HttpGet]

        public ActionResult<List<string>> GetDepartmentList()
        {
            var roleClaim = ValidateTokenAndGetRole();

            if (string.IsNullOrEmpty(roleClaim) || roleClaim != "Admin")
            {
                return Forbid();
            }

            var data = _repository.GetAllDepartments();
            return data.Any() ? Ok(data) : NoContent();
        }


        [HttpDelete]
        public ActionResult DeleteStudent(int id)
        {
            var roleClaim = ValidateTokenAndGetRole();

            if (string.IsNullOrEmpty(roleClaim) || roleClaim != "Admin")
            {
                return Forbid();
            }

            if (_repository.DeleteStudent(id))
            {
                return Ok(id);
            }

            return NoContent();
        }


        [Route("view/{id}")]
        [HttpGet]
        public ActionResult GetStudent(int id)
        {
            var roleClaim = ValidateTokenAndGetRole();

            if (string.IsNullOrEmpty(roleClaim) || roleClaim != "Admin")
            {
                return Forbid();
            }

            var student = _repository.GetStudent(id);
            return Ok(student);
        }

        [HttpPatch("{id}")]

        public ActionResult Update_Student(int id, [FromBody] Command c1)
        {
            var roleClaim = ValidateTokenAndGetRole();

            if (string.IsNullOrEmpty(roleClaim) || roleClaim != "Admin")
            {
                return Forbid();
            }

            var student = _repository.UpdateStudent(c1);
            return Ok(student);
        }

        [Route("DashBoard/info")]
        [HttpGet]

        public ActionResult Record()
        {
            var roleClaim = ValidateTokenAndGetRole();

            if (string.IsNullOrEmpty(roleClaim))
            {
                return Forbid();
            }

            return Ok(_repository.Info());
        }

        [AllowAnonymous]
        [Route("Register")]
        [HttpPost]
        public ActionResult<Register> RegisterUser(RegisterDto r1)
        {
            try
            {
                var data = _repository.Register(r1);
                return data != null ? Ok(data) : BadRequest("Failed");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return NoContent();
            }
        }

        [AllowAnonymous]
        [Route("Login")]
        [HttpPost]
        public ActionResult<string> Login(Login r1)
        {
            try
            {
                var token = _repository.Login(r1);
                return token != null ? Ok(new { Token = token }) : BadRequest("Failed");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return NoContent();
            }
        }
    }
}
